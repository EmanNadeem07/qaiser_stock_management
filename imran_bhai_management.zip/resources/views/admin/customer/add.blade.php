@extends('admin.layouts.master')
@section('content')
    <div class="content-wrapper">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <h2 class="py-3 text-center">Add Customer</h2>
                    <form action="{{ route('customer.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="input-group mt-3">
                            <span class="input-group-text" id="inputGroup-sizing-default">Picture</span>
                            <input name="avatar" type="file" class="form-control" aria-label="Sizing example input"
                                aria-describedby="inputGroup-sizing-default" {{ old('avatar') }}>
                        </div>
                        @error('avatar')
                            <strong><span style="color: red">{{ $message }}</span></strong>
                        @enderror
                        <div class="input-group mt-3">
                            <span class="input-group-text" id="inputGroup-sizing-default">Customer Name</span>
                            <input name="name" type="text" class="form-control" aria-label="Sizing example input"
                                aria-describedby="inputGroup-sizing-default" {{ old('name') }}>
                        </div>
                        @error('name')
                            <strong><span style="color: red">{{ $message }}</span></strong>
                        @enderror
                        <div class="input-group mt-3">
                            <span class="input-group-text" id="inputGroup-sizing-default">Phone</span>
                            <input name="phone" type="text" class="form-control" aria-label="Sizing example input"
                                aria-describedby="inputGroup-sizing-default" {{ old('phone') }}>
                        </div>
                        @error('phone')
                            <strong><span style="color: red">{{ $message }}</span></strong>
                        @enderror
                        <div class="form-group mt-3">
                            <select id="city" name="city" class="form-control">
                                <option value="">Select City</option>
                                @foreach ($cities as $city)
                                    <option value="{{ $city->id }}">{{ $city->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        @error('phone')
                            <strong><span style="color: red">{{ $message }}</span></strong>
                        @enderror
                        <div class="input-group mt-3">
                            <span class="input-group-text" id="inputGroup-sizing-default">Balance</span>
                            <input name="balance" type="text" class="form-control" aria-label="Sizing example input"
                                aria-describedby="inputGroup-sizing-default" {{ old('balance') }}>
                        </div>
                        @error('balance')
                            <strong><span style="color: red">{{ $message }}</span></strong>
                        @enderror
                        <div class="container mt-3">
                            <div class="col-md-12 text-center">
                                <button type="submit" class="btn btn-primary">Add Customer</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
