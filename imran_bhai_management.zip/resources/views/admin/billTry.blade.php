@extends('admin.layouts.master')
@section('content')
    <div class="content-wrapper">
        <div class="container-fluid">
            <form action="{{ route('save.data') }}" method="POST" id="dataForm">
                @csrf
                <h3 class="mt-1">Customer Details</h3>
                <div class="row">
                    <div class="col">
                        <label for="name">Name</label>
                        <input type="text" id="name" name="name" class="form-control">
                    </div>
                    <div class="col">
                        <label for="phone">Phone</label>
                        <input type="tel" id="phone" name="phone" class="form-control">
                    </div>
                </div>

                <label for="city">City</label>
                <input type="text" id="city" name="city" class="form-control">

                <label for="barcode">Barcode</label>
                <input type="text" id="barcode" name="barcode" class="form-control">
                <table class="table mt-3">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody id="productDetails">

                    </tbody>
                </table>
                <div id="totalAmount" class="mt-2">
                    Total Amount: <span id="totalValue">0</span>
                </div>
                <button type="submit" class="btn btn-primary mt-3">Submit</button>
            </form>
        </div>
    </div>
    <script>
        var products = {}; // Keep track of products by barcode
        var formDataArray = []; // Array to store form data

        $('#barcode').on('input', function() {
            var inputData = $(this).val();
            var url = "{{ route('product.by.code', ':inputData') }}";
            url = url.replace(':inputData', inputData);

            if (products[inputData]) {
                var quantityInput = products[inputData].find('td:nth-child(3) input');
                var quantity = parseInt(quantityInput.val()) + 1;
                quantityInput.val(quantity).trigger('input');

                // Update the quantity in the formDataArray
                var productId = products[inputData].data('product-id');
                updateQuantityInFormData(productId, quantity);
                updateTotalAmount();
            } else {
                $.ajax({
                    type: 'GET',
                    url: url,
                    success: function(response) {
                        var newRow = $('<tr data-product-id="' + response.data.id + '"></tr>');
                        var nameCol = $('<td><p>' + response.data.name + '</p></td>');
                        var priceCol = $('<td><p>' + response.data.selling_price + '</p></td>');
                        var quantityCol = $('<td><input type="number" name="quantity" value="1"></td>');
                        var totalCol = $('<td><p>' + response.data.selling_price + '</p></td>');

                        newRow.append(nameCol);
                        newRow.append(priceCol);
                        newRow.append(quantityCol);
                        newRow.append(totalCol);

                        $('#productDetails').append(newRow);
                        products[inputData] = newRow;

                        quantityCol.find('input').on('input', function() {
                            var quantity = $(this).val();
                            var price = response.data.selling_price;
                            var total = quantity * price;
                            totalCol.find('p').text(total);
                            updateTotalAmount();

                            // Update the quantity in the formDataArray
                            updateQuantityInFormData(response.data.id, quantity);
                        });

                        // Save the data in formDataArray
                        var formData = {
                            product_id: response.data.id,
                            quantity: 1,
                        };
                        formDataArray.push(formData);
                        console.log(formDataArray);

                        updateTotalAmount();
                    },
                    error: function(xhr, status, error) {
                        console.error(error);
                    }
                });
            }
        });

        // Handle form submission
        $('#dataForm').on('submit', function(event) {
            event.preventDefault();

            // alert(formDataArray);

            // Add the formDataArray as a hidden field in the form
            var formDataInput = $('<input type="hidden" name="form_data" value="' + JSON.stringify(formDataArray) +
                '">');

            $(this).append(formDataInput);

            // Submit the form
            // $(this).unbind('submit').submit();

        });

        function updateQuantityInFormData(productId, newQuantity) {
            for (var i = 0; i < formDataArray.length; i++) {
                if (formDataArray[i].product_id === productId) {
                    formDataArray[i].quantity = newQuantity;
                    break;
                }
            }
        }

        function updateTotalAmount() {
            var totalAmount = 0;
            $('#productDetails tr').each(function() {
                var totalCol = $(this).find('td:last p');
                var totalText = totalCol.text();
                totalAmount += parseFloat(totalText || 0);
            });
            $('#totalValue').text(totalAmount);
        }
    </script>
@endsection
