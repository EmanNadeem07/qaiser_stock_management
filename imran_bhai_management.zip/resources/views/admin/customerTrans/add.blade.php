@extends('admin.layouts.master')
@section('content')
    <style>
        /* Basic styles for the product count container */
        .product-count {
            display: flex;
            align-items: center;
            width: 120px;
            border: 1px solid #ccc;
            border-radius: 4px;
            overflow: hidden;
        }

        /* Style for the minus button */
        .product-count .btn-minus {
            background-color: #f0f0f0;
            padding: 8px;
            cursor: pointer;
            user-select: none;
        }

        /* Style for the plus button */
        .product-count .btn-plus {
            background-color: #f0f0f0;
            padding: 8px;
            cursor: pointer;
            user-select: none;
        }

        /* Style for the count display */
        .product-count .count-display {
            flex-grow: 1;
            text-align: center;
            font-size: 18px;
            font-weight: bold;
        }
    </style>
    <div class="content-wrapper">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="container">
                        <h2 class="py-3 text-center">Add Bill</h2>
                        <form id="addCustomerBillForm" action="{{ route('transaction.customer.store') }}" method="POST"
                            enctype="multipart/form-data">
                            @csrf
                            <input type="hidden" name="id" value="{{ $id }}">
                            <input type="hidden" name="count" id="count">
                            <div class="input-group mt-3">
                                <span class="input-group-text" id="inputGroup-sizing-default">Date</span>
                                <input name="date" type="date" class="form-control" aria-label="Sizing example input"
                                    aria-describedby="inputGroup-sizing-default" {{ old('date') }}>
                            </div>
                            @error('date')
                                <strong><span style="color: red">{{ $message }}</span></strong>
                            @enderror
                            <div class="input-group mt-3">
                                <span class="input-group-text" id="inputGroup-sizing-default">Bill No</span>
                                <input name="bill_no" type="text" class="form-control" aria-label="Sizing example input"
                                    aria-describedby="inputGroup-sizing-default" {{ old('name') }}>
                            </div>
                            @error('bill_no')
                                <strong><span style="color: red">{{ $message }}</span></strong>
                            @enderror
                            <div class="input-group mt-3">
                                <span class="input-group-text" id="inputGroup-sizing-default">Bill Picture</span>
                                <input name="bill_picture" type="file" class="form-control"
                                    aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"
                                    {{ old('bill_picture') }}>
                            </div>
                            @error('bill_picture')
                                <strong><span style="color: red">{{ $message }}</span></strong>
                            @enderror
                            <div class="input-group mt-3">
                                <span class="input-group-text" id="inputGroup-sizing-default">Bill Amount</span>
                                <input name="in" type="numeric" class="form-control" aria-label="Sizing example input"
                                    aria-describedby="inputGroup-sizing-default" {{ old('in') }}>
                            </div>
                            @error('in')
                                <strong><span style="color: red">{{ $message }}</span></strong>
                            @enderror
                            <div class="product-count mt-3">
                                <div class="btn-minus">-</div>
                                <div class="count-display">0</div>
                                <div class="btn-plus">+</div>
                            </div>
                            {{-- <div class="form-group">
                                <label for="category">Category:</label>
                                <select id="category" name="category" class="form-control">
                                    <option value="">Select Category</option>
                                    @foreach ($categories as $category)
                                        <option value="{{ $category->id }}">{{ $category->name }}</option>
                                    @endforeach
                                </select>
                            </div> --}}
                            {{-- <div class="form-group">
                                <label for="product">Product:</label>
                                <select id="product" name="product" class="form-control">
                                    <option value="">Select Product</option>
                                    @foreach ($products as $product)
                                        <option value="{{ $product->id }}">{{ $product->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="input-group mt-3">
                                <span class="input-group-text" id="inputGroup-sizing-default">Quantity</span>
                                <input name="quantity" type="numeric" class="form-control" aria-label="Sizing example input"
                                    aria-describedby="inputGroup-sizing-default" {{ old('quantity') }}>
                            </div>
                            @error('quantity')
                                <strong><span style="color: red">{{ $message }}</span></strong>
                            @enderror
                            <div class="input-group mt-3">
                                <span class="input-group-text" id="inputGroup-sizing-default">Price Per Unit</span>
                                <input name="price_per_unit" type="numeric" class="form-control"
                                    aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"
                                    {{ old('price_per_unit') }}>
                            </div>
                            @error('price_per_unit')
                                <strong><span style="color: red">{{ $message }}</span></strong>
                            @enderror --}}
                            <div class="more_products" id="more_products"></div>
                            <input type="hidden" id="product_details_json" name="product_details_json">

                            <div class="container mt-3">
                                <div class="col-md-12 text-center">
                                    <button type="submit" class="btn btn-primary">Add Bill</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        const countDisplay = document.querySelector('.count-display');
        const btnMinus = document.querySelector('.btn-minus');
        const btnPlus = document.querySelector('.btn-plus');
        let count = 0;
        btnMinus.addEventListener('click', () => {
            if (count > 1) {
                count--;
                countDisplay.textContent = count;
                $('#count').val(count);
            }
        });

        btnPlus.addEventListener('click', () => {
            count++;
            countDisplay.textContent = count;
            $('#count').val(count);
            var productInputs = '';
            for (var i = 1; i <= count; i++) {
                productInputs += `<div class="form-group">
                                <label for="product">Product:</label>
                                <select id="product_${i}" name="product_${i}" class="form-control">
                                    <option value="">Select Product</option>
                                    @foreach ($products as $product)
                                        <option value="{{ $product->id }}">{{ $product->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="input-group mt-3">
                                <span class="input-group-text" id="inputGroup-sizing-default">Quantity</span>
                                <input name="quantity_${i}" id ="quantity_${i}" type="numeric" class="form-control" aria-label="Sizing example input"
                                    aria-describedby="inputGroup-sizing-default" {{ old('quantity_${i}') }}>
                            </div>
                            @error('quantity_${i}')
                                <strong><span style="color: red">{{ $message }}</span></strong>
                            @enderror
                            <div class="input-group mt-3">
                                <span class="input-group-text" id="inputGroup-sizing-default">Price Per Unit</span>
                                <input name="price_per_unit_${i}" id="price_per_unit_${i}" type="numeric" class="form-control"
                                    aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"
                                    {{ old('price_per_unit_${i}') }}>
                            </div>
                            @error('price_per_unit_${i}')
                                <strong><span style="color: red">{{ $message }}</span></strong>
                            @enderror`;
            }
            $('#more_products').html(productInputs);

        });
    </script>
    <script>
        $(document).ready(function() {
            $('#addCustomerBillForm').on('submit', function(e) {

                e.preventDefault();

                var currentQuantity = parseInt($('#count').val());

                var productsData = [];
                for (var i = 1; i <= currentQuantity; i++) {
                    var product = $('#product_' + i).val();
                    var quantity = $('#quantity_' + i).val();
                    var price_per_unit = $('#price_per_unit_' + i).val();

                    productsData.push({
                        product: product,
                        quantity: quantity,
                        price_per_unit: price_per_unit
                    });
                }
                console.log(productsData);
                $('#product_details_json').val(JSON.stringify(productsData));
                $(this).unbind('submit').submit();
            });
        });
    </script>
@endsection
