@extends('admin.layouts.master')
@section('content')
    <style>
        /* Basic styles for the product count container */
        .product-count {
            display: flex;
            align-items: center;
            width: 120px;
            border: 1px solid #ccc;
            border-radius: 4px;
            overflow: hidden;
        }

        /* Style for the minus button */
        .product-count .btn-minus {
            background-color: #f0f0f0;
            padding: 8px;
            cursor: pointer;
            user-select: none;
        }

        /* Style for the plus button */
        .product-count .btn-plus {
            background-color: #f0f0f0;
            padding: 8px;
            cursor: pointer;
            user-select: none;
        }

        /* Style for the count display */
        .product-count .count-display {
            flex-grow: 1;
            text-align: center;
            font-size: 18px;
            font-weight: bold;
        }
    </style>
    <div class="content-wrapper">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="container">
                        <h2 class="py-3 text-center">Add Bill</h2>
                        <form id="addSupplierBillForm" action="{{ route('transaction.store') }}" method="POST"
                            enctype="multipart/form-data">
                            @csrf
                            <input type="hidden" name="id" value="{{ $id }}">
                            <input type="hidden" name="count" id="count">
                            <div class="input-group mt-3">
                                <span class="input-group-text" id="inputGroup-sizing-default">Date</span>
                                <input name="date" type="date" class="form-control" aria-label="Sizing example input"
                                    aria-describedby="inputGroup-sizing-default" {{ old('date') }}>
                            </div>
                            @error('date')
                                <strong><span style="color: red">{{ $message }}</span></strong>
                            @enderror
                            <div class="input-group mt-3">
                                <span class="input-group-text" id="inputGroup-sizing-default">Bill No</span>
                                <input name="bill_no" type="text" class="form-control" aria-label="Sizing example input"
                                    aria-describedby="inputGroup-sizing-default" {{ old('name') }}>
                            </div>
                            @error('bill_no')
                                <strong><span style="color: red">{{ $message }}</span></strong>
                            @enderror
                            <div class="input-group mt-3">
                                <span class="input-group-text" id="inputGroup-sizing-default">Bill Picture</span>
                                <input name="bill_picture" type="file" class="form-control"
                                    aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"
                                    {{ old('bill_picture') }}>
                            </div>
                            @error('bill_picture')
                                <strong><span style="color: red">{{ $message }}</span></strong>
                            @enderror
                            <div class="input-group mt-3">
                                <span class="input-group-text" id="inputGroup-sizing-default">Bill Amount</span>
                                <input name="in" type="numeric" class="form-control" aria-label="Sizing example input"
                                    aria-describedby="inputGroup-sizing-default" {{ old('in') }}>
                            </div>
                            @error('in')
                                <strong><span style="color: red">{{ $message }}</span></strong>
                            @enderror

                            <div class="mt-3 align-self-center ">
                                <h3>Product Details</h3>
                            </div>
                            <div class="product-count">
                                <div class="btn-minus">-</div>
                                <div class="count-display">0</div>
                                <div class="btn-plus">+</div>
                            </div>
                            {{-- <div style="border: 2px solid #000000 mt-3">
                                <div class="input-group">
                                    <span class="input-group-text" id="inputGroup-sizing-default">Name</span>
                                    <input name="name" type="text" class="form-control"
                                        aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"
                                        {{ old('name') }}>
                                </div>
                                @error('name')
                                    <strong><span style="color: red">{{ $message }}</span></strong>
                                @enderror

                                <div class="input-group mt-3">
                                    <span class="input-group-text" id="inputGroup-sizing-default">Category</span>
                                    <select name="category" id="category" class="form-control">
                                        <option disabled selected>Select Category</option>
                                        @foreach ($categories as $category)
                                            <option value="{{ $category->id }}">{{ $category->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                @error('category')
                                    <strong><span style="color: red">{{ $message }}</span></strong>
                                @enderror
                            </div>
                            <div class="p-3">___________________________OR______________________________</div>
                            <div style="border: 2px solid #000000">
                                <div class="input-group">
                                    <span class="input-group-text" id="inputGroup-sizing-default">Products</span>
                                    <select name="category" id="category" class="form-control">
                                        <option disabled selected>Select Products</option>
                                        @foreach ($products as $product)
                                            <option value="{{ $product->id }}">{{ $product->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            @error('category')
                                <strong><span style="color: red">{{ $message }}</span></strong>
                            @enderror
                            <div class="input-group mt-3">
                                <span class="input-group-text" id="inputGroup-sizing-default">Quantity</span>
                                <input name="quantity" type="number" class="form-control" aria-label="Sizing example input"
                                    aria-describedby="inputGroup-sizing-default" {{ old('quantity') }}>
                            </div>
                            @error('quantity')
                                <strong><span style="color: red">{{ $message }}</span></strong>
                            @enderror --}}
                            <div class="more_products" id="more_products">

                            </div>
                            <input type="hidden" id="product_details_json" name="product_details_json">
                            <div class="container mt-3">
                                <div class="col-md-12 text-center">
                                    <button type="submit" class="btn btn-primary">Add Bill</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    {{-- <script>
        $(document).ready(function() {
            console.log('hi');
            let counter = 1;
            var pDetails = '';
            $("#addMoreProduct").click(function() {
                for (var i = 1; i <= currentQuantity; i++) {
                    pDetails += `<div style="border: 2px solid #000000 mt-3">
                                <div class="input-group">
                                    <span class="input-group-text" id="inputGroup-sizing-default">Name</span>
                                    <input name="name" type="text" class="form-control"
                                        aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"
                                        {{ old('name') }}>
                                </div>
                                @error('name')
                                    <strong><span style="color: red">{{ $message }}</span></strong>
                                @enderror

                                <div class="input-group mt-3">
                                    <span class="input-group-text" id="inputGroup-sizing-default">Category</span>
                                    <select name="category" id="category" class="form-control">
                                        <option disabled selected>Select Category</option>
                                        @foreach ($categories as $category)
                                            <option value="{{ $category->id }}">{{ $category->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                @error('category')
                                    <strong><span style="color: red">{{ $message }}</span></strong>
                                @enderror
                            </div>
                            <div class="p-3">___________________________OR______________________________</div>
                            <div style="border: 2px solid #000000">
                                <div class="input-group">
                                    <span class="input-group-text" id="inputGroup-sizing-default">Products</span>
                                    <select name="category" id="category" class="form-control">
                                        <option disabled selected>Select Products</option>
                                        @foreach ($products as $product)
                                            <option value="{{ $product->id }}">{{ $product->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            @error('category')
                                <strong><span style="color: red">{{ $message }}</span></strong>
                            @enderror
                            <div class="input-group mt-3">
                                <span class="input-group-text" id="inputGroup-sizing-default">Quantity</span>
                                <input name="quantity" type="number" class="form-control" aria-label="Sizing example input"
                                    aria-describedby="inputGroup-sizing-default" {{ old('quantity') }}>
                            </div>
                            @error('quantity')
                                <strong><span style="color: red">{{ $message }}</span></strong>
                            @enderror`;
                }
                $('#more_products').html(pDetails);
                counter++;
            });
        });
    </script> --}}
    <script>
        $(document).ready(function() {
            $('#addSupplierBillForm').on('submit', function(e) {

                e.preventDefault();

                var currentQuantity = parseInt($('#count').val());

                var productsData = [];
                for (var i = 1; i <= currentQuantity; i++) {
                    var name = $('#name_' + i).val();
                    var category = $('#category_' + i).val();
                    var product = $('#product_' + i).val();
                    var quantity = $('#quantity_' + i).val();
                    var price_per_unit = $('#price_per_unit_' + i).val();
                    var selling_price = $('#selling_price_' + i).val();


                    productsData.push({
                        name: name,
                        category: category,
                        product: product,
                        quantity: quantity,
                        price_per_unit: price_per_unit,
                        selling_price: selling_price
                    });
                }
                console.log(productsData);
                $('#product_details_json').val(JSON.stringify(productsData));
                $(this).unbind('submit').submit();
            });
        });
    </script>
    <script>
        const countDisplay = document.querySelector('.count-display');
        const btnMinus = document.querySelector('.btn-minus');
        const btnPlus = document.querySelector('.btn-plus');
        let count = 0;
        btnMinus.addEventListener('click', () => {
            if (count > 1) {
                count--;
                countDisplay.textContent = count;
                $('#count').val(count);
            }
        });

        btnPlus.addEventListener('click', () => {
            count++;
            countDisplay.textContent = count;
            $('#count').val(count);
            var productInputs = '';
            for (var i = 1; i <= count; i++) {
                productInputs += `<div style="border: 2px solid #000000 mt-3">
                                <div class=" mt-3 input-group">
                                    <span class="input-group-text" id="inputGroup-sizing-default">Name</span>
                                    <input name="name_${i}" id="name_${i}" type="text" class="form-control"
                                        aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"
                                        {{ old('name_${i}') }}>
                                </div>
                                @error('name')
                                    <strong><span style="color: red">{{ $message }}</span></strong>
                                @enderror

                                <div class="input-group mt-3">
                                    <span class="input-group-text" id="inputGroup-sizing-default">Category</span>
                                    <select name="category_${i}" id="category_${i}" class="form-control">
                                        <option disabled selected>Select Category</option>
                                        @foreach ($categories as $category)
                                            <option value="{{ $category->id }}">{{ $category->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                @error('category')
                                    <strong><span style="color: red">{{ $message }}</span></strong>
                                @enderror
                            </div>
                            <div class="p-3">___________________________OR______________________________</div>
                            <div style="border: 2px solid #000000">
                                <div class="input-group">
                                    <span class="input-group-text" id="inputGroup-sizing-default">Products</span>
                                    <select name="product_${i}" id="product_${i}" class="form-control">
                                        <option  selected>Select Products</option>
                                        @foreach ($products as $product)
                                            <option value="{{ $product->id }}">{{ $product->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            @error('category')
                                <strong><span style="color: red">{{ $message }}</span></strong>
                            @enderror
                            <div class="input-group mt-3">
                                <span class="input-group-text" id="inputGroup-sizing-default">Quantity</span>
                                <input name="quantity_${i}" id="quantity_${i}" type="number" class="form-control" aria-label="Sizing example input"
                                    aria-describedby="inputGroup-sizing-default" {{ old('quantity') }}>
                            </div>
                            @error('quantity')
                                <strong><span style="color: red">{{ $message }}</span></strong>
                            @enderror
                            <div class="input-group mt-3">
                                <span class="input-group-text" id="inputGroup-sizing-default">Buying Price</span>
                                <input name="price_per_unit_${i}" id="price_per_unit_${i}" type="number" class="form-control" aria-label="Sizing example input"
                                    aria-describedby="inputGroup-sizing-default" {{ old('price_per_unit_${i}') }}>
                            </div>
                            @error('price_per_unit_${i}')
                                <strong><span style="color: red">{{ $message }}</span></strong>
                            @enderror
                            <div class="input-group mt-3">
                                <span class="input-group-text" id="inputGroup-sizing-default">Selling Price</span>
                                <input name="selling_price_${i}" id="selling_price_${i}" type="number" class="form-control" aria-label="Sizing example input"
                                    aria-describedby="inputGroup-sizing-default" {{ old('selling_price_${i}') }}>
                            </div>
                            @error('selling_price_${i}')
                                <strong><span style="color: red">{{ $message }}</span></strong>
                            @enderror`;


            }
            $('#more_products').html(productInputs);

        });
    </script>
@endsection
