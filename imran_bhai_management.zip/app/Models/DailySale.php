<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DailySale extends Model
{
    use HasFactory;
    protected $fillable = [
        'name',
        'phone',
        'city',
        'date',
        'bill_no',
        'bill_picture',
        'gross',
    ];
    public function dailySalesProducts()
    {
        return $this->hasMany(DailySaleProduct::class);
    }
}
