<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Bill extends Model
{
    use HasFactory;
    protected $fillable = ['date', 'customer_transaction_id', 'amount'];
    public function customer_transaction()
    {
        return $this->belongsTo(CustomerTransaction::class);
    }
    public function bill_products()
    {
        return $this->hasMany(BillProduct::class);
    }
}
