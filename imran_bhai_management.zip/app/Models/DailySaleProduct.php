<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DailySaleProduct extends Model
{
    use HasFactory;
    protected $fillable = [
        'product_id',
        'quantity',
        'pricePerUnit',
        'total',
        'daily_sale_id',
    ];
    public function daily_sale()
    {
        return $this->belongsTo(DailySale::class);
    }
    public function product()
    {
        return $this->belongsTo(Product::class);
    }
}
