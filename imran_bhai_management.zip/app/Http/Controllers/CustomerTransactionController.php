<?php

namespace App\Http\Controllers;

use App\Models\Bill;
use App\Models\BillProduct;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Customer;
use App\Models\CustomerTransaction;
use App\Models\Product;
use App\Models\Profit;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class CustomerTransactionController extends Controller
{
    public function add($id)
    {
        try {
            $categories = Category::all();
            $products = Product::all();
            return view('admin.customerTrans.add', compact('id', 'categories', 'products'));
        } catch (\Throwable $th) {
            return redirect(route('dashboard'))->with(['status' => false, 'message' => 'something went wrong']);
        }
    }
    public function store(Request $request)
    {
        try {
            DB::beginTransaction();
            $user = Auth::user();
            $billName = null;
            $customer = Customer::findorfail($request->id);

            if ($request->hasFile('bill_picture')) {
                $bill = $request->file('bill_picture');
                $billName = time() . '_' . $bill->getClientOriginalName();
                $bill->storeAs('images/bills', $billName);
            }
            // if ($request->in) {
            // }
            if ($request->deposit) {
                $remaining = $customer->balance - $request->deposit;
                CustomerTransaction::create([
                    'date' => $request->date,
                    'out' => $request->deposit,
                    'remaining' => $remaining,
                    'customer_id' => $request->id,
                ]);
                $customer->update([
                    'id' => $customer->id,
                    'balance' => $customer->balance - $request->deposit,
                ]);
                $user->update([
                    'id' => $user->id,
                    'myAccount' =>  $user->myAccount + $request->deposit,
                ]);

                DB::commit();
                return redirect(route('customer.list'))->with(['status' => true, 'message' => 'Sent Money Successfully']);
            } else {
                // $remaining = $customer->balance + $request->in;
                $customer_transaction = CustomerTransaction::create([
                    'date' => $request->date,
                    'bill_no' => $request->bill_no,
                    'bill_picture' => $billName,
                    // 'in' => $request->in,
                    // 'remaining' => $remaining,
                    'customer_id' => $request->id,
                ]);
                $bill = Bill::create([
                    'date' => $request->date,
                    'customer_transaction_id' => $customer_transaction->id
                ]);

                $date = Carbon::parse($request->date);
                $formattedDate = $date->format('F Y');

                $productDetailsData = json_decode($request->input('product_details_json'), true);
                $grossTotal = 0;

                foreach ($productDetailsData as $details) {
                    $product = Product::findorfail($details['product']);
                    if ($product->quantity >= intval($details['quantity'])) {
                        $product->update([
                            'id' => $product->id,
                            'quantity' => ($product->quantity) - (intval($details['quantity'])),
                        ]);
                        Profit::create([
                            'amount' => ((floatval($details['price_per_unit'])) - ($product->price_per_unit)) * intval($details['quantity']),
                            'month' => $formattedDate,
                        ]);
                        BillProduct::create([
                            'product_id' => $product->id,
                            'bill_id' => $bill->id,
                            'quantity' => intval($details['quantity']),
                            'price_per_unit' => floatval($details['price_per_unit']),
                            'total' => intval($details['quantity']) * floatval($details['price_per_unit']),
                        ]);
                        $grossTotal += intval($details['quantity']) * floatval($details['price_per_unit']);
                    } else {
                        return redirect(route('customer.list'))->with(['status' => false, 'message' => $product->name . " is Out Of Stock"]);
                    }
                }
                // dd(floatval($customer->balance), $grossTotal);
                $customer_transaction->update([
                    'in' => $grossTotal,
                    'remaining' => floatval($customer->balance) + $grossTotal,
                ]);
                $bill->update([
                    'amount' => $grossTotal
                ]);
                $customer->update([
                    'id' => $customer->id,
                    'balance' => $customer->balance + $grossTotal,
                ]);
                DB::commit();
                return redirect(route('customer.list'))->with(['status' => true, 'message' => 'Bill Added Successfully']);
            }
        } catch (\Throwable $th) {
            DB::rollback();
            dd($th->getMessage());
        }
    }
    public function sendMoney($id)
    {
        try {
            $customer = Customer::findorfail($id);
            return view('admin.customerTrans.deposit', compact('customer'));
        } catch (\Throwable $th) {
            //throw $th;
        }
    }
    public function details($id)
    {
        try {
            $customer = Customer::findorfail($id);
            $transactions = $customer->customerTransactions()->orderBy('date', 'desc')->get();
            return view('admin.customerTrans.details', compact('transactions', 'customer'));
        } catch (\Throwable $th) {
            dd($th->getMessage());
        }
    }
}
