<?php

namespace App\Http\Controllers;

use App\Http\Requests\AddCustomerRequest;
use App\Models\Customer;
use Illuminate\Support\Facades\DB;
use App\Models\City;

use Illuminate\Http\Request;

class CustomerController extends Controller
{
    public function add()
    {
        try {
            $cities = City::all();
            return view('admin.customer.add', compact('cities'));
        } catch (\Throwable $th) {
            return redirect(route('dashboard'))->with(['status' => false, 'message' => 'Something went wrong']);
        }
    }
    public function store(AddCustomerRequest $request)
    {
        try {
            DB::beginTransaction();
            $avatarName = null;
            if ($request->hasFile('avatar')) {
                $avatar = $request->file('avatar');
                $avatarName = time() . '_' . $avatar->getClientOriginalName();
                $avatar->storeAs('images/avatars', $avatarName);
            }
            Customer::create([
                'name' => $request->name,
                'balance' => $request->balance,
                'city_id' => $request->city,
                'phone' => $request->phone,
                'image' => $avatarName,
            ]);
            DB::commit();
            return redirect(route('customer.list'))->with(['status' => true, 'message' => 'Customer Added Successfully']);
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect(route('customer.list'))->with(['status' => false, 'message' => 'something went wrong']);
        }
    }

    public function list()
    {
        try {
            $customers = Customer::all();
            return view('admin.customer.list', compact('customers'));
        } catch (\Throwable $th) {
            return redirect(route('dashboard'))->with(['status' => false, 'message' => 'something went wrong']);
        }
    }
    public function customerByCity($id)
    {
        try {
            $city = City::findorfail($id);
            $customers = $city->customers;
            return view('admin.customer.list', compact('customers'));
        } catch (\Throwable $th) {
            //throw $th;
        }
    }
}
