<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\City;

class CityController extends Controller
{
    public function add()
    {
        try {
            return view('admin.city.add');
        } catch (\Throwable $th) {
            return redirect(route('dashboard'))->with(['status' =>  false, 'message' => 'something went wrong']);
        }
    }
    public function store(Request $request)
    {
        try {
            DB::beginTransaction();
            $city = City::create([
                'name' => $request->name,
            ]);
            DB::commit();
            return redirect(route('city.list'))->with(['status' => true, 'message' => 'City Added Successfully']);
        } catch (\Throwable $th) {
            DB::rollBack();
            return redirect(route('dashboard'))->with(['status' => false, 'message' => 'something went wrong']);
        }
    }
    public function list()
    {
        try {
            $cities = City::all();
            return view('admin.city.list', compact('cities'));
        } catch (\Throwable $th) {
            return redirect(route('dashboard'))->with(['status' =>  false, 'message' => 'something went wrong']);
        }
    }
    public function delete($id)
    {
        try {
            DB::beginTransaction();
            $city = City::findorfail($id);
            $city->delete();
            DB::commit();
            return redirect(route('city.list'))->with(['status' => true, 'message' => 'City Deleted Sucessfully']);
        } catch (\Throwable $th) {
            DB::rollBack();
            return redirect(route('dashboard'))->with(['status' => false, 'message' => 'something went wrong']);
        }
    }
}
