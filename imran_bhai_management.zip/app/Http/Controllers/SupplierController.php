<?php

namespace App\Http\Controllers;

use App\Http\Requests\AddSupplierRequest;
use App\Models\City;
use App\Models\Supplier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SupplierController extends Controller
{
    public function add()
    {
        try {
            $cities = City::all();
            return view('admin.supplier.add', compact('cities'));
        } catch (\Throwable $th) {
            dd($th->getMessage());
        }
    }
    public function store(AddSupplierRequest $request)
    {
        try {
            DB::beginTransaction();
            $avatarName = null;
            if ($request->hasFile('avatar')) {
                $avatar = $request->file('avatar');
                $avatarName = time() . '_' . $avatar->getClientOriginalName();
                $avatar->storeAs('images/avatars', $avatarName);
            }

            Supplier::create([
                'name' => $request->name,
                'balance' => $request->balance,
                'city_id' => $request->city,
                'phone' => $request->phone,
                'image' => $avatarName,
            ]);
            DB::commit();
            return redirect(route('supllier.list'))->with(['status' => true, 'message' => 'Supplier Added Successfully']);
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect(route('supllier.list'))->with(['status' => false, 'message' => 'Something went wrong']);
        }
    }
    public function list()
    {
        try {
            $suppliers = Supplier::paginate(8);
            return view('admin.supplier.list', compact('suppliers'));
        } catch (\Throwable $th) {
            return redirect(route('dashboard'))->with(['status' => false, 'message' => 'something went wrong']);
        }
    }
    public function supplierByCity($id)
    {
        try {
            $city = City::findorfail($id);
            $suppliers = $city->suppliers;
            return view('admin.supplier.list', compact('suppliers'));
        } catch (\Throwable $th) {
            //throw $th;
        }
    }
}
