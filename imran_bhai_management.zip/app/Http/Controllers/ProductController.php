<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Milon\Barcode\DNS1D;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;
use Picqer\Barcode\BarcodeGenerator;
use Picqer\Barcode\BarcodeGeneratorPNG;


class ProductController extends Controller
{
    public function add()
    {
        try {
            $categories = Category::all();
            return view('admin.product.add', compact('categories'));
        } catch (\Throwable $th) {
            return redirect(route('dashboard'))->with(['status' => false, 'message' => 'Something went wrong']);
        }
    }
    public function store(Request $request)
    {
        try {
            DB::beginTransaction();

            $randomBarcode = str_pad(mt_rand(1, 999999999), 9, '0', STR_PAD_LEFT);

            $generator = new BarcodeGeneratorPNG();
            $barcodeData = $generator->getBarcode($randomBarcode, $generator::TYPE_CODE_128);

            $filename = 'barcode_' . time() . '.png';
            $publicPath = public_path('barcodes');

            if (!file_exists($publicPath)) {
                mkdir($publicPath, 0755, true);
            }
            $filePath = $publicPath . '/' . $filename;
            file_put_contents($filePath, $barcodeData);

            Product::create([
                'name' => $request->name,
                'quantity' => $request->quantity,
                'price_per_unit' => $request->pricePerUnit,
                'product_code' => $randomBarcode,
                'category_id' => $request->category,
                'picture' => $filename,
            ]);
            DB::commit();
            return redirect(route('product.list'))->with(['status' => true, 'message' => 'Product Added Successfully']);
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect(route('product.list'))->with(['status' => false, 'message' => 'Something went wrong']);
        }
    }
    public function showBarcode($fileName)
    {
        try {
            return view('barcode', compact('fileName'));
        } catch (\Throwable $th) {
            //throw $th;
        }
    }
    public function list()
    {
        try {
            $products = Product::all();
            return view('admin.product.list', compact('products'));
        } catch (\Throwable $th) {
            dd($th->getMessage());
        }
    }
    public function salePage($id)
    {
        try {
            $product = Product::findorfail($id);
            return view('admin.product.sale', compact('product'));
        } catch (\Throwable $th) {
            //throw $th;
        }
    }
    public function sale(Request $request)
    {
        try {
            DB::beginTransaction();
            $product = Product::findorfail($request->product_id);
            $product->update([
                'id' => $product->id,
                'quantity' => $product->quantity - $request->quantity,
            ]);
            DB::commit();
            return redirect(route('product.list'))->with(['status' => true, 'message' => 'Stock Updated Successfully']);
        } catch (\Throwable $th) {
            DB::rollBack();
            return redirect(route('product.list'))->with(['status' => false, 'message' => 'Something went wrong']);
        }
    }
    public function searchByBarcode($barcode)
    {
        try {
            $product = Product::where('product_code', $barcode)->first();
            return response()->json(['data' => $product]);
        } catch (\Throwable $th) {
            return response()->json('not found');
        }
    }
}
