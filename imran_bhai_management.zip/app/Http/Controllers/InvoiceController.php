<?php

namespace App\Http\Controllers;

use App\Models\CustomerTransaction;
use Illuminate\Http\Request;

class InvoiceController extends Controller
{
    public function invoice($id)
    {
        try {
            $transaction = CustomerTransaction::findorfail($id);
            return view('admin.invoice', compact('transaction'));
        } catch (\Throwable $th) {
            //throw $th;
        }
    }
}
