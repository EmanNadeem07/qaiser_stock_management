<?php

namespace App\Http\Controllers;

use App\Models\DailySale;
use App\Models\DailySaleProduct;
use App\Models\Product;
use Illuminate\Http\Request;
use App\Models\Profit;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ProfitController extends Controller
{
    public function profitByMonth()
    {
        try {
            $profits = Profit::all();
            $groupedProfits = [];

            foreach ($profits as $profit) {
                $month = $profit->month;
                $amount = $profit->amount;

                // Extract the month and year from the string
                $date = date_create_from_format('F Y', $month);
                $key = $date->format('F Y'); // Format the date as 'Month Year' for grouping

                if (!isset($groupedProfits[$key])) {
                    $groupedProfits[$key] = 0;
                }

                $groupedProfits[$key] += $amount;
            }
            return view('admin.profitList', compact('groupedProfits'));
            // dd($groupedProfits);
        } catch (\Throwable $th) {
            //throw $th;
        }
    }
    public function addDailySale()
    {
        try {
            $products = Product::all();
            return view('admin.dailySale', compact('products'));
        } catch (\Throwable $th) {
            //throw $th;
        }
    }
    public function saleout(Request $request)
    {
        try {
            DB::beginTransaction();
            $dailySale = DailySale::create([
                'name' => $request->name,
                'phone' => $request->phone,
                'city' => $request->city,
                'date' => $request->date,
                'bill_no' => $request->bill_no,
            ]);

            $productDetailsData = json_decode($request->input('product_details_json'), true);
            $grossTotal = 0;

            $date = Carbon::parse($request->date);
            $formattedDate = $date->format('F Y');
            // dd($productDetailsData);
            foreach ($productDetailsData as $details) {
                $product = Product::findorfail($details['product']);
                if ($product->quantity >= intval($details['quantity'])) {
                    $product->update([
                        'id' => $product->id,
                        'quantity' => ($product->quantity) - (intval($details['quantity'])),
                    ]);
                    Profit::create([
                        'amount' => ((floatval($details['price_per_unit'])) - ($product->price_per_unit)) * intval($details['quantity']),
                        'month' => $formattedDate,
                    ]);
                    DailySaleProduct::create([
                        'product_id' => $product->id,
                        'daily_sale_id' => $dailySale->id,
                        'quantity' => intval($details['quantity']),
                        'pricePerUnit' => floatval($details['price_per_unit']),
                        'total' => intval($details['quantity']) * floatval($details['price_per_unit']),
                    ]);
                    $grossTotal += intval($details['quantity']) * floatval($details['price_per_unit']);
                } else {
                    return redirect(route('customer.list'))->with(['status' => false, 'message' => $product->name . " is Out Of Stock"]);
                }
            }
            $dailySale->update([
                'id' => $dailySale->id,
                'gross' => $grossTotal
            ]);
            DB::commit();
            return redirect(route('daily_sales'))->with(['status' => true, 'message' => 'SaleOut Succeed']);
        } catch (\Throwable $th) {
            DB::rollback();
            dd($th->getMessage());
        }
    }
    public function daily_sales()
    {
        try {
            $dailySales = DailySale::all();
            return view('admin.dailySaleList', compact('dailySales'));
        } catch (\Throwable $th) {
            //throw $th;
        }
    }
    public function dailySaleInvoice($id)
    {
        try {
            $dailySale = DailySale::findorfail($id);
            return view('admin.dailySaleInvoice', compact('dailySale'));
        } catch (\Throwable $th) {
            //throw $th;
        }
    }
    public function saveData(Request $request)
    {
        try {
            DB::beginTransaction();
            // Validate the incoming request data, ensuring the form_data field is an array
            // $validatedData = $request->validate([
            //     'form_data' => 'required',
            // ]);
            $formData = json_decode($request->input('form_data'), true);
            dd($formData);


            $totalAmount = 0; // Initialize total bill amount

            $dailySale = DailySale::create([
                'name' => $request->name,
                'phone' => $request->phone,
                'city' => $request->city,
                'date' => now(),
                'bill_no' => $request->bill_no,
            ]);

            $date = Carbon::parse($request->date);
            $formattedDate = $date->format('F Y');


            // Loop through the form data and process each entry
            foreach ($validatedData['form_data'] as $formData) {
                dd($formData);
                $product = Product::find($formData['product_id']);

                if ($product->quantity >= intval($formData['quantity'])) {

                    Profit::create([
                        'amount' => ((floatval($formData['selling_price'])) - ($product->price_per_unit)) * intval($formData['quantity']),
                        'month' => $formattedDate,
                    ]);
                    $product->update([
                        'id' => $product->id,
                        'quantity' => $product->quantity - $formData['quantity'],
                    ]);
                    DailySaleProduct::create([
                        'product_id' => $product->id,
                        'daily_sale_id' => $dailySale->id,
                        'quantity' => intval($formData['quantity']),
                        'pricePerUnit' => floatval($formData['price_per_unit']),
                        'total' => intval($formData['quantity']) * floatval($formData['selling_price']),
                    ]);

                    // Calculate the total cost for each product and add it to the total amount
                    $totalAmount += $product->selling_price * $formData['quantity'];
                } else {
                    return "out of stock";
                }
            }
            $dailySale->update([
                'id' => $dailySale->id,
                'gross' => $totalAmount
            ]);

            // Perform any other necessary actions

            // Return a response with the total amount
            return redirect(route('daily_sales'))->with(['status' => true, 'message' => 'Checkout Sucessfully']);
        } catch (\Throwable $th) {
            dd($th->getMessage());
        }
    }
}
