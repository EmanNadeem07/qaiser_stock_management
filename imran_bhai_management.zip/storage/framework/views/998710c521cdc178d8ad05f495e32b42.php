<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <?php if(Session::has('message')): ?>
            <div class="alert">
                <?php if(Session::get('status') == false): ?>
                    <p class="alert alert-danger"><?php echo e(Session::get('message')); ?></p>
                <?php else: ?>
                    <p class="alert alert-success"><?php echo e(Session::get('message')); ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <div class="container-fluid">
            <h2 class="text-center mt-3"><strong>All Suppliers</strong></h2>
            <div class="text-left">
                <a href="<?php echo e(route('supplier.add')); ?>" class="btn btn-sm btn-success">Add Supplier</a>
            </div>
            <section class="mt-3">
                <div class="container">
                    <div class="row">
                        <table class="table" id="supplier_table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Image</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Phone</th>
                                    <th scope="col">City</th>
                                    <th scope="col">Balance</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $counter = 0;
                                ?>
                                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $counter = $counter + 1;
                                    ?>
                                    <tr>
                                        <th scope="row"><?php echo e($counter); ?></th>
                                        <td><img src="<?php echo e(asset('images/avatars/' . $supplier->image)); ?>" alt="hi"
                                                srcset=""></td>
                                        <td><?php echo e($supplier->name); ?></td>
                                        <td><?php echo e($supplier->phone); ?></td>
                                        <td><?php echo e($supplier->city->name); ?></td>

                                        <td><?php echo e($supplier->balance); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('transaction.add', $supplier->id)); ?>"
                                                class="btn btn-sm btn-danger">Add Bill</a>
                                            <a href="<?php echo e(route('transaction.send', $supplier->id)); ?>"
                                                class="btn btn-sm btn-warning">Send Money</a>
                                            <a href="<?php echo e(route('transaction.details', $supplier->id)); ?>"
                                                class="btn btn-sm btn-secondary">Transactions</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\imran_bhai_management\resources\views/admin/supplier/list.blade.php ENDPATH**/ ?>