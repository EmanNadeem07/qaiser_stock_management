<footer class="main-footer">
    
</footer>
<?php /**PATH D:\laragon\www\imran_bhai_management\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>