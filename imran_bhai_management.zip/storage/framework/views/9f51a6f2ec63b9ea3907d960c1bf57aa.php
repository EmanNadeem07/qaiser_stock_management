<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <?php if(Session::has('message')): ?>
            <div class="alert">
                <?php if(Session::get('status') == false): ?>
                    <p class="alert alert-danger"><?php echo e(Session::get('message')); ?></p>
                <?php else: ?>
                    <p class="alert alert-success"><?php echo e(Session::get('message')); ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('expense.byDate')); ?>" method="GET">
            <?php echo csrf_field(); ?>
            <input type="date" name="date" id="date">
            <button type="submit">Find</button>
        </form>
        <div class="container-fluid">
            <h2 class="text-center mt-3"><strong>Expenses</strong></h2>
            <section style="padding-top:60px">
                <div class="container">
                    <div class="row">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Description</th>
                                    <th scope="col">Amount</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $counter = 0;
                                ?>
                                <?php if(Route::is('expense.byDate')): ?>
                                    <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $counter = $counter + 1;
                                        ?>
                                        <tr>
                                            <th scope="row"><?php echo e($counter); ?></th>
                                            <td><?php echo e($expense->date); ?></td>
                                            <td><?php echo e($expense->description); ?></td>
                                            <td><?php echo e($expense->amount); ?></td>
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $counter = $counter + 1;
                                        ?>
                                        <tr>
                                            <th scope="row"><?php echo e($counter); ?></th>
                                            <td><?php echo e($expense->date); ?></td>
                                            <td><?php echo e($expense->description); ?></td>
                                            <td><?php echo e($expense->amount); ?></td>
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\imran_bhai_management\resources\views/admin/expense/list.blade.php ENDPATH**/ ?>