<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="container">
            <div class="row justify-content-center">

                <div class="container">
                    <h3 class="py-3 text-center"><?php echo e($customer->name); ?> </h3>
                </div>
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Date</th>
                        <th scope="col">Bill No</th>
                        <th scope="col">Bill Picture</th>
                        <th scope="col">In</th>
                        <th scope="col">Out</th>
                        <th scope="col">Remaining</th>
                        <th scope="col">Invoice</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($transaction->date); ?></td>
                            <td><?php echo e($transaction->bill_no); ?></td>
                            <?php if($transaction->bill_picture): ?>
                                <td><img src="<?php echo e(asset('images/bills/' . $transaction->bill_picture)); ?>" alt="hi">
                                </td>
                            <?php else: ?>
                                <td></td>
                            <?php endif; ?>
                            <td><span class="badge bg-danger "><?php echo e($transaction->in); ?></span></td>

                            <?php if($transaction->out): ?>
                                <td><span class="badge bg-success "> <?php echo e($transaction->out); ?></span></td>
                            <?php else: ?>
                                <td></td>
                            <?php endif; ?>
                            <td><?php echo e($transaction->remaining); ?></td>
                            <?php if($transaction->in): ?>
                                <td><a class="btn btn-sm btn-success " href="<?php echo e(route('invoice', $transaction->id)); ?>">View
                                        Invoice</a></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\imran_bhai_management\resources\views/admin/customerTrans/details.blade.php ENDPATH**/ ?>