<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <?php if(Session::has('message')): ?>
            <div class="alert">
                <?php if(Session::get('status') == false): ?>
                    <p class="alert alert-danger"><?php echo e(Session::get('message')); ?></p>
                <?php else: ?>
                    <p class="alert alert-success"><?php echo e(Session::get('message')); ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <div class="container-fluid">
            <h2 class="text-center mt-3"><strong>Daily Sales</strong></h2>
            <div class="text-left">
                <a href="<?php echo e(route('addDailySale')); ?>" class="btn btn-sm btn-success">Sale An Item</a>
            </div>
            <section style="padding-top:60px">
                <div class="container">
                    <div class="row">
                        <table class="table" id="dailySales_table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Customer Name</th>
                                    <th scope="col">Phone</th>
                                    <th scope="col">Address</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Amount</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $counter = 0;
                                ?>
                                <?php $__currentLoopData = $dailySales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dailySale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $counter = $counter + 1;
                                    ?>
                                    <tr>
                                        <th scope="row"><?php echo e($counter); ?></th>

                                        <td><?php echo e($dailySale->name); ?></td>
                                        <td><?php echo e($dailySale->phone); ?></td>
                                        <td><?php echo e($dailySale->city); ?></td>
                                        <td><?php echo e($dailySale->date); ?></td>
                                        <td><?php echo e($dailySale->gross); ?></td>

                                        <td>
                                            <a href="<?php echo e(route('dailySaleInvoice', $dailySale->id)); ?>"
                                                class="btn btn-sm btn-danger">View
                                                Invoice</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\imran_bhai_management\resources\views/admin/dailySaleList.blade.php ENDPATH**/ ?>